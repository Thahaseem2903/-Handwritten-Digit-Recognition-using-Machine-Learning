
from flask import Flask, render_template, request, jsonify
import tensorflow as tf
import numpy as np
from PIL import Image

app = Flask(__name__)
app = Flask(__name__, template_folder='D:\\templates')
model = tf.keras.models.load_model('model.h5')
# Route from app1.py
@app.route('/')
def hello():
    return 'Hello, World!'

# Route from app2.py
@app.route('/about')
def about():
    return 'This is the About page'

# Route from app3.py
@app.route('/contact')
def contact():
    return 'Contact us at example@example.com'

# Route from app4.py
@app.route('/dashboard')
def dashboard():
    # Logic to retrieve user data or perform other tasks
    return render_template('dashboard.html')

# Additional routes
@app.route('/predict', methods=['POST'])
def predict():
    if 'image' not in request.files:
        return jsonify({'error': 'No image found'})

    image = request.files['image']
    img = Image.open(image)
    img = preprocess_image(img)
    prediction = make_prediction(img)

    return jsonify({'prediction': str(prediction)})

def preprocess_image(img):
    img = img.convert('L')  # Convert to grayscale
    img = img.resize((28, 28))  # Resize to 28x28 pixels
    img = np.array(img)  # Convert to NumPy array
    img = img / 255.0  # Normalize pixel values (0-1)
    img = np.expand_dims(img, axis=0)  # Add extra dimension for batch
    return img

def make_prediction(img):
    predictions = model.predict(img)
    digit = np.argmax(predictions)
    return digit

if __name__ == '__main__':
    app.run(debug=True)

