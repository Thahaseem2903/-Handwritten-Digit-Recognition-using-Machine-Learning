
import sys
from cx_Freeze import setup, Executable

build_exe_options = {
    "packages": ["numpy", "PIL"],
    "include_files": ["model.h5"],
    "excludes": ["tensorflow"]
}

base = None
if sys.platform == "win32":
    base = "Win32GUI"

executables = [
    Executable('app.py', base=base)
]

setup(
    name='Handwritten Digit Recognition',
    version='1.0',
    description='Handwritten Digit Recognition Application',
    options={"build_exe": build_exe_options},
    executables=executables
)
